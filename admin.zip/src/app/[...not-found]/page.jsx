import React from "react";

const NotFoundPage = () => {
   return (
      <div className="bg-green-200">
         <h1 className="text-green-500">NotFoundPage</h1>
      </div>
   );
};

export default NotFoundPage;
