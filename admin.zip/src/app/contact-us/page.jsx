import React from "react";

const ContactUsPage = () => {
   return <div className="bg-white rounded-lg mx-4 p-4">ContactUsPage</div>;
};

export default ContactUsPage;
