let BankDetails={
    "Bank":{
        "account_number":"12332222",
        "name":"Abdulaziz",
        
    },
    "JazzCash":{
        "account_number":"12332222",
        "name":"Abdulaziz",
        
    },
    "Easypaisa":{
        "account_number":"12332222",
        "name":"Abdulaziz",
        
    },

}