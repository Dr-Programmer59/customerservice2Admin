
let Questions={
    "Create id":{
        "sub_categories":["Betpro Exch","Lg Exch"],
        "questions":[],
        
    },
    "Deposit":{
        "sub_categories":["Bank","JazzCash","Easypaisa"],
        "questions":{
            "Bank":["These are details of Bank ",]
        }



    },
    "Withdrawal":[],
    "Apk ids":[],

}